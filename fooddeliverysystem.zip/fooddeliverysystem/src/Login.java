
package src;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Login extends JFrame {

    private JTextField emailField;
    private JPasswordField passwordField;

    private final Color RED = new Color(190, 35, 35);
    private final Color ORANGE = new Color(245, 135, 35);
    private final Color CREAM = new Color(255, 247, 235);
    private final Color DARK = new Color(65, 35, 30);

    public Login() {

        setTitle("Food Delivery System");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new GridLayout(1, 2));
        mainPanel.setBackground(CREAM);

        // LEFT PANEL
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBackground(RED);
        leftPanel.setBorder(new EmptyBorder(65, 35, 50, 35));

        JLabel logo = new JLabel();
        ImageIcon icon = new ImageIcon("logo.png");

        if (icon.getIconWidth() > 0) {
            Image img = icon.getImage().getScaledInstance(
                260, 260, Image.SCALE_SMOOTH
            );
            logo.setIcon(new ImageIcon(img));
        } else {
            logo.setText("FOOD DELIVERY");
            logo.setForeground(Color.WHITE);
            logo.setFont(new Font("Arial", Font.BOLD, 27));
        }

        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel tagline = new JLabel("GOOD FOOD, GREAT MOOD!");
        tagline.setForeground(Color.WHITE);
        tagline.setFont(new Font("Arial", Font.BOLD, 20));
        tagline.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel welcome = new JLabel("Fresh Food at Your Doorstep");
        welcome.setForeground(Color.WHITE);
        welcome.setFont(new Font("Arial", Font.PLAIN, 15));
        welcome.setAlignmentX(Component.CENTER_ALIGNMENT);

        leftPanel.add(Box.createVerticalGlue());
        leftPanel.add(logo);
        leftPanel.add(Box.createVerticalStrut(25));
        leftPanel.add(tagline);
        leftPanel.add(Box.createVerticalStrut(12));
        leftPanel.add(welcome);
        leftPanel.add(Box.createVerticalGlue());

        // RIGHT PANEL
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(CREAM);
        rightPanel.setBorder(new EmptyBorder(75, 55, 65, 55));

        JLabel heading = new JLabel("Welcome Back!");
        heading.setFont(new Font("Arial", Font.BOLD, 30));
        heading.setForeground(DARK);

        JLabel subtitle = new JLabel("Login to continue ordering food");
        subtitle.setFont(new Font("Arial", Font.PLAIN, 15));
        subtitle.setForeground(Color.GRAY);

        JLabel emailLabel = new JLabel("Email Address or User Name");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 14));
        emailLabel.setForeground(DARK);

        emailField = new JTextField();
        emailField.setFont(new Font("Arial", Font.PLAIN, 15));
        emailField.setMaximumSize(new Dimension(350, 42));
        emailField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 205, 190)),
            new EmptyBorder(8, 12, 8, 12)
        ));

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        passwordLabel.setForeground(DARK);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Arial", Font.PLAIN, 15));
        passwordField.setMaximumSize(new Dimension(350, 42));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 205, 190)),
            new EmptyBorder(8, 12, 8, 12)
        ));

        // BUTTONS
        JButton loginButton = new JButton("LOGIN");
        styleButton(loginButton, RED);

        JButton registerButton = new JButton("CREATE NEW ACCOUNT");
        styleButton(registerButton, ORANGE);

        JButton adminButton = new JButton("ADMIN LOGIN");
        styleButton(adminButton, ORANGE);

        JButton backButton = new JButton("← BACK");
        styleButton(backButton, DARK);

        // LOGIN ACTION
        loginButton.addActionListener(e -> login());

        // REGISTER PAGE
        registerButton.addActionListener(e -> {
            dispose();
            new Register();
        });

        // ADMIN PAGE
        adminButton.addActionListener(e -> {
            dispose();
            new AdminLogin();
        });

        // BACK TO WELCOME
        backButton.addActionListener(e -> {
            dispose();
            new Welcome();
        });

        // ADD COMPONENTS
        rightPanel.add(heading);
        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(subtitle);
        rightPanel.add(Box.createVerticalStrut(40));

        rightPanel.add(emailLabel);
        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(emailField);
        rightPanel.add(Box.createVerticalStrut(25));

        rightPanel.add(passwordLabel);
        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(passwordField);
        rightPanel.add(Box.createVerticalStrut(30));

        rightPanel.add(loginButton);
        rightPanel.add(Box.createVerticalStrut(15));
        rightPanel.add(registerButton);
        rightPanel.add(Box.createVerticalStrut(15));
        rightPanel.add(adminButton);
        rightPanel.add(Box.createVerticalStrut(15));
        rightPanel.add(backButton);

        mainPanel.add(leftPanel);
        mainPanel.add(rightPanel);

        add(mainPanel);

        setVisible(true);
    }

    // BUTTON DESIGN
    private void styleButton(JButton button, Color color) {

        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setMaximumSize(new Dimension(350, 45));
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    // LOGIN VALIDATION
    private void login() {

        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (email.isEmpty() || password.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Please enter email and password!"
            );
            return;
        }

        String sql =
            "SELECT customer_id FROM customers " +
            "WHERE (email = ? OR name = ?) AND password = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, email);
            ps.setString(2, email);
            ps.setString(3, password);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    int customerId = rs.getInt("customer_id");

                    JOptionPane.showMessageDialog(
                        this,
                        "Login Successful!"
                    );

                    dispose();
                    new FoodMenu(customerId);

                } else {

                    JOptionPane.showMessageDialog(
                        this,
                        "Invalid Email or Password!"
                    );
                }
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "Database Error: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> new Login());
    }
}
