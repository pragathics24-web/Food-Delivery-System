package src;

import java.util.ArrayList;

public class CartManager {

    private ArrayList<CartItem> items = new ArrayList<>();

    public void addItem(int foodId, String name,
                        double price, int quantity) {

        for (CartItem item : items) {

            if (item.getFoodId() == foodId) {

                item.setQuantity(
                    item.getQuantity() + quantity
                );

                return;
            }
        }

        items.add(new CartItem(
            foodId, name, price, quantity
        ));
    }

    public ArrayList<CartItem> getItems() {
        return items;
    }

    public double getTotal() {

        double total = 0;

        for (CartItem item : items) {
            total += item.getTotal();
        }

        return total;
    }

    public void clearCart() {
        items.clear();
    }
}