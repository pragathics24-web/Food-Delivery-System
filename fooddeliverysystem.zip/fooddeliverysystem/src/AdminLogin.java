
package src;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class AdminLogin extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;

    private final Color MAROON = new Color(128, 25, 45);
    private final Color CREAM = new Color(255, 248, 238);
    private final Color ORANGE = new Color(238, 145, 55);
    private final Color DARK = new Color(65, 45, 40);

    public AdminLogin() {

        setTitle("Food Delivery - Admin Login");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new GridLayout(1, 2));

        // LEFT BRANDING PANEL
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBackground(MAROON);
        leftPanel.setBorder(new EmptyBorder(60, 30, 50, 30));

        JLabel logo = new JLabel("FOOD DELIVERY");
        logo.setFont(new Font("Arial", Font.BOLD, 29));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel tagline = new JLabel("Good Food, Great Mood!");
        tagline.setFont(new Font("Arial", Font.ITALIC, 18));
        tagline.setForeground(new Color(255, 210, 150));
        tagline.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel adminIcon = new JLabel("ADMIN");
        adminIcon.setFont(new Font("Arial", Font.BOLD, 35));
        adminIcon.setForeground(Color.WHITE);
        adminIcon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel welcome = new JLabel("Welcome Administrator");
        welcome.setFont(new Font("Arial", Font.BOLD, 19));
        welcome.setForeground(Color.WHITE);
        welcome.setAlignmentX(Component.CENTER_ALIGNMENT);

        leftPanel.add(Box.createVerticalGlue());
        leftPanel.add(logo);
        leftPanel.add(Box.createVerticalStrut(15));
        leftPanel.add(tagline);
        leftPanel.add(Box.createVerticalStrut(75));
        leftPanel.add(adminIcon);
        leftPanel.add(Box.createVerticalStrut(20));
        leftPanel.add(welcome);
        leftPanel.add(Box.createVerticalGlue());

        // RIGHT LOGIN PANEL
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(CREAM);
        rightPanel.setBorder(new EmptyBorder(95, 55, 70, 55));

        JLabel heading = new JLabel("Admin Login");
        heading.setFont(new Font("Arial", Font.BOLD, 30));
        heading.setForeground(DARK);
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel("Login to manage your food delivery system");
        subtitle.setFont(new Font("Arial", Font.PLAIN, 14));
        subtitle.setForeground(Color.GRAY);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        usernameLabel.setForeground(DARK);
        usernameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        usernameField = new JTextField();
        styleField(usernameField);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        passwordLabel.setForeground(DARK);
        passwordLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        passwordField = new JPasswordField();
        styleField(passwordField);

        JButton loginButton = new JButton("LOGIN");
        styleButton(loginButton, MAROON);
        JButton backButton = new JButton("← BACK");

backButton.setFont(new Font("Arial", Font.BOLD, 14));
backButton.setForeground(Color.WHITE);
backButton.setBackground(new Color(230, 135, 55));
backButton.setFocusPainted(false);
backButton.setBorderPainted(false);
backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
backButton.setMaximumSize(new Dimension(350, 45));
backButton.setAlignmentX(Component.LEFT_ALIGNMENT);

backButton.addActionListener(e -> {
    dispose();
    new Welcome();
});
        loginButton.addActionListener(e -> loginAdmin());

        rightPanel.add(heading);
        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(subtitle);
        rightPanel.add(Box.createVerticalStrut(40));

        rightPanel.add(usernameLabel);
        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(usernameField);
        rightPanel.add(Box.createVerticalStrut(25));

        rightPanel.add(passwordLabel);
        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(passwordField);
        rightPanel.add(Box.createVerticalStrut(35));

        rightPanel.add(loginButton);
        rightPanel.add(Box.createVerticalStrut(15));
rightPanel.add(backButton);
        mainPanel.add(leftPanel);
        mainPanel.add(rightPanel);

        add(mainPanel);
        setVisible(true);
    }

    private void styleField(JTextField field) {

        field.setFont(new Font("Arial", Font.PLAIN, 15));
        field.setMaximumSize(new Dimension(350, 42));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 205, 190)),
            new EmptyBorder(8, 12, 8, 12)
        ));
    }

    private void styleButton(JButton button, Color color) {

        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setMaximumSize(new Dimension(350, 45));
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private void loginAdmin() {

        String username = usernameField.getText().trim();
        String password =
            new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(
                this, "Please enter username and password!"
            );
            return;
        }

        String sql =
            "SELECT * FROM admins WHERE username=? AND password=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    JOptionPane.showMessageDialog(
                        this, "Admin Login Successful!"
                    );

                    new AdminDashboard();
                    dispose();

                } else {

                    JOptionPane.showMessageDialog(
                        this,
                        "Invalid Admin Username or Password!"
                    );
                }
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                this, e.getMessage()
            );
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminLogin());
    }
}
