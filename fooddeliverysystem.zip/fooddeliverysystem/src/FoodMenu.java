package src;

import java.awt.*;
import java.io.File;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;

public class FoodMenu extends JFrame {

    private int customerId;
    private CartManager cartManager = new CartManager();
    private JButton cartButton;

    private final Color MAROON = new Color(128, 25, 45);
    private final Color CREAM = new Color(255, 248, 238);
    private final Color ORANGE = new Color(238, 145, 55);
    private final Color DARK = new Color(65, 45, 40);

    public FoodMenu(int customerId) {
        this.customerId = customerId;

        setTitle("Food Delivery System - Food Menu");
        setSize(1050, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(CREAM);

        // HEADER
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBackground(MAROON);
        headerPanel.setBorder(new EmptyBorder(20, 10, 20, 10));

        JLabel title = new JLabel("WELCOME TO FOOD DELIVERY", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 29));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel tagline = new JLabel("Good Food, Great Mood!");
        tagline.setFont(new Font("Arial", Font.ITALIC, 17));
        tagline.setForeground(new Color(255, 210, 150));
        tagline.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(title);
        headerPanel.add(Box.createVerticalStrut(8));
        headerPanel.add(tagline);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // FOOD CARDS PANEL
        JPanel menuPanel = new JPanel(new GridLayout(0, 2, 20, 20));
        menuPanel.setBackground(CREAM);
        menuPanel.setBorder(new EmptyBorder(25, 30, 25, 30));

        loadFoodItems(menuPanel);

        JScrollPane scrollPane = new JScrollPane(menuPanel);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(CREAM);
        scrollPane.getVerticalScrollBar().setUnitIncrement(20);

        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // BOTTOM PANEL
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(MAROON);
        bottomPanel.setBorder(new EmptyBorder(15, 10, 15, 10));

        JButton profileButton = new JButton("MANAGE PROFILE");
        JButton historyButton = new JButton("ORDER HISTORY");
        JButton donationButton = new JButton("FOOD DONATION");
        cartButton = new JButton("VIEW CART (0)");
        JButton logoutButton = new JButton("LOGOUT");

        styleButton(profileButton, CREAM, MAROON);
        styleButton(historyButton, CREAM, MAROON);
        styleButton(donationButton, CREAM, MAROON);
        styleButton(cartButton, ORANGE, Color.WHITE);
        styleButton(logoutButton, ORANGE, Color.WHITE);

        profileButton.addActionListener(e -> manageProfile());

        historyButton.addActionListener(e ->
            new OrderHistory(customerId)
        );

        // FOOD DONATION BUTTON
        donationButton.addActionListener(e ->
            new FoodDonationCustomer()
        );

        cartButton.addActionListener(e -> showCart());

        logoutButton.addActionListener(e -> {
            dispose();
            new Login();
        });

        bottomPanel.add(profileButton);
        bottomPanel.add(historyButton);
        bottomPanel.add(donationButton);
        bottomPanel.add(cartButton);
        bottomPanel.add(logoutButton);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }

    // LOAD FOOD ITEMS
    private void loadFoodItems(JPanel menuPanel) {
        String sql = "SELECT * FROM food";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int foodId = rs.getInt("food_id");
                String foodName = rs.getString("food_name");
                double price = rs.getDouble("price");

                menuPanel.add(createFoodCard(foodId, foodName, price));
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                this, "Food Loading Error: " + ex.getMessage()
            );
        }
    }

    // CREATE FOOD CARD
    private JPanel createFoodCard(int foodId, String foodName, double price) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);

        card.setBorder(
            BorderFactory.createCompoundBorder(
                new LineBorder(new Color(220, 175, 145), 1),
                new EmptyBorder(15, 15, 15, 15)
            )
        );

        JLabel imageLabel = new JLabel();
        imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        imageLabel.setPreferredSize(new Dimension(180, 145));
        imageLabel.setMaximumSize(new Dimension(180, 145));

        String imageName = getImageName(foodName);
        File imageFile = new File("images/" + imageName);

        if (imageFile.exists()) {
            ImageIcon originalIcon = new ImageIcon(imageFile.getAbsolutePath());

            Image scaledImage = originalIcon.getImage()
                .getScaledInstance(180, 145, Image.SCALE_SMOOTH);

            imageLabel.setIcon(new ImageIcon(scaledImage));
        } else {
            imageLabel.setText("Image not found");
            imageLabel.setForeground(Color.GRAY);
        }

        JLabel nameLabel = new JLabel(foodName);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 21));
        nameLabel.setForeground(MAROON);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel priceLabel = new JLabel(String.format("Rs. %.2f", price));
        priceLabel.setFont(new Font("Arial", Font.BOLD, 18));
        priceLabel.setForeground(DARK);
        priceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton orderButton = new JButton("ADD TO CART");
        styleButton(orderButton, MAROON, Color.WHITE);
        orderButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        orderButton.addActionListener(e ->
            addToCart(foodId, foodName, price)
        );

        card.add(imageLabel);
        card.add(Box.createVerticalStrut(12));
        card.add(nameLabel);
        card.add(Box.createVerticalStrut(7));
        card.add(priceLabel);
        card.add(Box.createVerticalStrut(12));
        card.add(orderButton);

        return card;
    }

    // ADD FOOD TO CART
    private void addToCart(int foodId, String foodName, double price) {
        String input = JOptionPane.showInputDialog(
            this, "Enter quantity for " + foodName + ":"
        );

        if (input == null) return;

        try {
            int quantity = Integer.parseInt(input);

            if (quantity <= 0) {
                JOptionPane.showMessageDialog(this, "Enter valid quantity!");
                return;
            }

            cartManager.addItem(foodId, foodName, price, quantity);
            updateCartButton();

            JOptionPane.showMessageDialog(
                this, foodName + " added to cart successfully!"
            );

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid quantity!");
        }
    }

    // UPDATE CART BUTTON
    private void updateCartButton() {
        int count = 0;

        for (CartItem item : cartManager.getItems()) {
            count += item.getQuantity();
        }

        cartButton.setText("VIEW CART (" + count + ")");
    }

    // VIEW CART
    private void showCart() {
        if (cartManager.getItems().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Your cart is empty!");
            return;
        }

        StringBuilder details = new StringBuilder();
        details.append("YOUR SHOPPING CART\n\n");

        for (CartItem item : cartManager.getItems()) {
            details.append(item.getFoodName())
                .append(" x ")
                .append(item.getQuantity())
                .append(" = Rs. ")
                .append(item.getTotal())
                .append("\n");
        }

        details.append("\n----------------------\n");
        details.append("TOTAL: Rs. ").append(cartManager.getTotal());

        Object[] options = {
            "CHECKOUT",
            "CONTINUE SHOPPING",
            "CLEAR CART"
        };

        int choice = JOptionPane.showOptionDialog(
            this,
            details.toString(),
            "MY CART",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            options,
            options[1]
        );

        if (choice == 0) {
            checkoutCart();

        } else if (choice == 2) {
            int confirm = JOptionPane.showConfirmDialog(
                this, "Clear all cart items?",
                "Clear Cart", JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                cartManager.clearCart();
                updateCartButton();
            }
        }
    }

    // CHECKOUT
    private void checkoutCart() {
        if (cartManager.getItems().isEmpty()) return;

        double total = cartManager.getTotal();

        String[] methods = {
            "Cash on Delivery",
            "UPI (Demo)"
        };

        String paymentMethod = (String) JOptionPane.showInputDialog(
            this,
            "Total Amount: Rs. " + total + "\nSelect Payment Method:",
            "Payment",
            JOptionPane.QUESTION_MESSAGE,
            null,
            methods,
            methods[0]
        );

        if (paymentMethod == null) return;

        String paymentStatus = "Pending";

        if (paymentMethod.equals("UPI (Demo)")) {
            int paymentConfirm = JOptionPane.showConfirmDialog(
                this,
                "Confirm Demo UPI Payment?\nAmount: Rs. " + total,
                "UPI Payment",
                JOptionPane.YES_NO_OPTION
            );

            if (paymentConfirm != JOptionPane.YES_OPTION) return;
            paymentStatus = "Paid";
        }

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Total Amount: Rs. " + total +
            "\nPayment Method: " + paymentMethod +
            "\n\nConfirm Order?",
            "Order Confirmation",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) return;

        String orderSql =
            "INSERT INTO orders " +
            "(customer_id, order_date, total_amount, status) " +
            "VALUES (?, CURDATE(), ?, ?)";

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                throw new SQLException("Database connection failed!");
            }

            con.setAutoCommit(false);

            try {
                int orderId;

                try (PreparedStatement ps = con.prepareStatement(
                    orderSql, Statement.RETURN_GENERATED_KEYS
                )) {
                    ps.setInt(1, customerId);
                    ps.setDouble(2, total);
                    ps.setString(3, "Pending");
                    ps.executeUpdate();

                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (!rs.next()) {
                            throw new SQLException("Order ID not generated!");
                        }
                        orderId = rs.getInt(1);
                    }
                }

                String itemSql =
                    "INSERT INTO order_items " +
                    "(order_id, food_id, quantity, price) " +
                    "VALUES (?, ?, ?, ?)";

                try (PreparedStatement ps = con.prepareStatement(itemSql)) {
                    for (CartItem item : cartManager.getItems()) {
                        ps.setInt(1, orderId);
                        ps.setInt(2, item.getFoodId());
                        ps.setInt(3, item.getQuantity());
                        ps.setDouble(4, item.getPrice());
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }

                String paymentSql =
                    "INSERT INTO payments " +
                    "(order_id, payment_method, payment_status, payment_date) " +
                    "VALUES (?, ?, ?, CURDATE())";

                try (PreparedStatement ps = con.prepareStatement(paymentSql)) {
                    ps.setInt(1, orderId);
                    ps.setString(2, paymentMethod);
                    ps.setString(3, paymentStatus);
                    ps.executeUpdate();
                }

                con.commit();

                cartManager.clearCart();
                updateCartButton();

                JOptionPane.showMessageDialog(
                    this,
                    "ORDER PLACED SUCCESSFULLY!\n\n" +
                    "Order ID: " + orderId +
                    "\nTotal: Rs. " + total +
                    "\nPayment: " + paymentMethod +
                    "\nPayment Status: " + paymentStatus
                );

            } catch (Exception ex) {
                con.rollback();
                throw ex;

            } finally {
                con.setAutoCommit(true);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                this, "Checkout Error: " + ex.getMessage()
            );
            ex.printStackTrace();
        }
    }

    // IMAGE FILE NAME
    private String getImageName(String foodName) {
        String name = foodName.toLowerCase().trim();

        if (name.contains("burger")) return "burger.jpg";
        if (name.contains("pizza")) return "pizza.jpg";

        if (name.contains("biriyani") || name.contains("biryani")) {
            return "biriyani.jpg";
        }

        if (name.contains("fried rice")) return "fried_rice.jpg";
        if (name.contains("sandwich")) return "sandwich.jpg";
        if (name.contains("noodles")) return "noodles.jpg";

        return "burger.jpg";
    }

    // BUTTON DESIGN
    private void styleButton(
        JButton button, Color background, Color foreground
    ) {
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(background);
        button.setForeground(foreground);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(180, 43));
    }

    // MANAGE CUSTOMER PROFILE
    private void manageProfile() {
        JTextField nameField = new JTextField(20);
        JTextField emailField = new JTextField(20);
        JTextField phoneField = new JTextField(20);
        JTextField addressField = new JTextField(20);

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                "SELECT name, email, phone, address " +
                "FROM customers WHERE customer_id=?"
             )) {

            ps.setInt(1, customerId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    nameField.setText(rs.getString("name"));
                    emailField.setText(rs.getString("email"));
                    phoneField.setText(rs.getString("phone"));
                    addressField.setText(rs.getString("address"));
                } else {
                    JOptionPane.showMessageDialog(
                        this, "Customer details not found!"
                    );
                    return;
                }
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                this, "Profile Loading Error: " + ex.getMessage()
            );
            return;
        }

        JDialog dialog = new JDialog(this, "Manage My Profile", true);
        dialog.setSize(450, 380);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel headingPanel = new JPanel();
        headingPanel.setBackground(MAROON);
        headingPanel.setBorder(new EmptyBorder(15, 10, 15, 10));

        JLabel heading = new JLabel("MY PROFILE");
        heading.setFont(new Font("Arial", Font.BOLD, 23));
        heading.setForeground(Color.WHITE);
        headingPanel.add(heading);

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 12, 18));
        formPanel.setBackground(CREAM);
        formPanel.setBorder(new EmptyBorder(25, 25, 25, 25));

        JLabel nameLabel = new JLabel("Customer Name:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel phoneLabel = new JLabel("Phone:");
        JLabel addressLabel = new JLabel("Address:");

        Font labelFont = new Font("Arial", Font.BOLD, 14);

        nameLabel.setFont(labelFont);
        emailLabel.setFont(labelFont);
        phoneLabel.setFont(labelFont);
        addressLabel.setFont(labelFont);

        nameLabel.setForeground(DARK);
        emailLabel.setForeground(DARK);
        phoneLabel.setForeground(DARK);
        addressLabel.setForeground(DARK);

        formPanel.add(nameLabel);
        formPanel.add(nameField);
        formPanel.add(emailLabel);
        formPanel.add(emailField);
        formPanel.add(phoneLabel);
        formPanel.add(phoneField);
        formPanel.add(addressLabel);
        formPanel.add(addressField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(CREAM);
        buttonPanel.setBorder(new EmptyBorder(5, 10, 15, 10));

        JButton updateButton = new JButton("UPDATE PROFILE");
        JButton closeButton = new JButton("CLOSE");

        styleButton(updateButton, MAROON, Color.WHITE);
        styleButton(closeButton, ORANGE, Color.WHITE);

        updateButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();
            String address = addressField.getText().trim();

            if (name.isEmpty() || email.isEmpty() ||
                phone.isEmpty() || address.isEmpty()) {
                JOptionPane.showMessageDialog(
                    dialog, "Please fill all the fields!"
                );
                return;
            }

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(
                    "UPDATE customers SET name=?, email=?, " +
                    "phone=?, address=? WHERE customer_id=?"
                 )) {

                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, phone);
                ps.setString(4, address);
                ps.setInt(5, customerId);

                int result = ps.executeUpdate();

                if (result > 0) {
                    JOptionPane.showMessageDialog(
                        dialog, "Profile Updated Successfully!"
                    );
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(
                        dialog, "Profile Update Failed!"
                    );
                }

            } catch (SQLIntegrityConstraintViolationException ex) {
                JOptionPane.showMessageDialog(
                    dialog, "This email is already registered!"
                );

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(
                    dialog, "Profile Update Error: " + ex.getMessage()
                );
            }
        });

        closeButton.addActionListener(e -> dialog.dispose());

        buttonPanel.add(updateButton);
        buttonPanel.add(closeButton);

        dialog.add(headingPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login());
    }
}