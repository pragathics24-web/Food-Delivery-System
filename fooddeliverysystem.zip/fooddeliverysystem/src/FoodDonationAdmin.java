
package src;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FoodDonationAdmin extends JFrame {

    Color maroon = new Color(105, 25, 38);
    Color cream = new Color(250, 244, 232);
    Color orange = new Color(230, 135, 55);
    Color darkText = new Color(65, 45, 40);

    JTextField foodField, quantityField, locationField, timeField;
    JTable table;
    DefaultTableModel model;
    JComboBox<String> statusBox;

    public FoodDonationAdmin() {

        setTitle("Food Donation Management");
        setSize(950, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(cream);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        // HEADER
        JLabel heading = new JLabel("FOOD DONATION MANAGEMENT");
        heading.setFont(new Font("Arial", Font.BOLD, 24));
        heading.setForeground(maroon);

        mainPanel.add(heading, BorderLayout.NORTH);

        // INPUT PANEL
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        inputPanel.setBackground(cream);
        inputPanel.setBorder(
            BorderFactory.createTitledBorder("Add Donation Details")
        );

        foodField = new JTextField();
        quantityField = new JTextField();
        locationField = new JTextField();
        timeField = new JTextField();

        inputPanel.add(new JLabel("Food Name:"));
        inputPanel.add(foodField);

        inputPanel.add(new JLabel("Quantity:"));
        inputPanel.add(quantityField);

        inputPanel.add(new JLabel("Pickup Location:"));
        inputPanel.add(locationField);

        inputPanel.add(new JLabel("Available Until:"));
        inputPanel.add(timeField);

        inputPanel.add(new JLabel("Date format:"));
        inputPanel.add(new JLabel("yyyy-MM-dd HH:mm:ss"));

        // TABLE
        String[] columns = {
            "ID", "Food Name", "Quantity",
            "Pickup Location", "Available Until", "Status"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setRowHeight(28);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.getTableHeader().setBackground(maroon);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        JScrollPane scrollPane = new JScrollPane(table);

        // BUTTONS
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(cream);

        JButton addButton = createButton("ADD DONATION");
        JButton updateButton = createButton("UPDATE STATUS");
        JButton deleteButton = createButton("DELETE");
        JButton refreshButton = createButton("REFRESH");

        statusBox = new JComboBox<>(new String[]{
            "Available", "Requested", "Approved", "Collected", "Expired"
        });

        addButton.addActionListener(e -> addDonation());
        updateButton.addActionListener(e -> updateStatus());
        deleteButton.addActionListener(e -> deleteDonation());
        refreshButton.addActionListener(e -> loadDonations());

        buttonPanel.add(addButton);
        buttonPanel.add(statusBox);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);

        // CENTER PANEL
        JPanel centerPanel = new JPanel(new BorderLayout(10, 15));
        centerPanel.setBackground(cream);
        centerPanel.add(inputPanel, BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        centerPanel.add(buttonPanel, BorderLayout.SOUTH);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        add(mainPanel);

        loadDonations();

        setVisible(true);
    }

    // BUTTON DESIGN
    private JButton createButton(String text) {

        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(maroon);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        return button;
    }

    // ADD DONATION
    private void addDonation() {

        String foodName = foodField.getText().trim();
        String quantityText = quantityField.getText().trim();
        String location = locationField.getText().trim();
        String availableUntil = timeField.getText().trim();

        if (foodName.isEmpty() || quantityText.isEmpty()
                || location.isEmpty() || availableUntil.isEmpty()) {

            JOptionPane.showMessageDialog(
                this, "Please fill all fields!"
            );
            return;
        }

        try {
            int quantity = Integer.parseInt(quantityText);

            if (quantity <= 0) {
                JOptionPane.showMessageDialog(
                    this, "Quantity must be greater than zero!"
                );
                return;
            }

            Timestamp timestamp = Timestamp.valueOf(availableUntil);

            String sql =
                "INSERT INTO food_donations " +
                "(food_name, quantity, pickup_location, available_until) " +
                "VALUES (?, ?, ?, ?)";

            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, foodName);
            ps.setInt(2, quantity);
            ps.setString(3, location);
            ps.setTimestamp(4, timestamp);

            ps.executeUpdate();

            ps.close();
            con.close();

            JOptionPane.showMessageDialog(
                this, "Donation added successfully!"
            );

            foodField.setText("");
            quantityField.setText("");
            locationField.setText("");
            timeField.setText("");

            loadDonations();

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                this, "Enter a valid quantity!"
            );

        } catch (IllegalArgumentException e) {

            JOptionPane.showMessageDialog(
                this, "Enter date like 2026-11-20 18:30:00"
            );

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    // LOAD DONATIONS
    private void loadDonations() {

        model.setRowCount(0);

        String sql =
            "SELECT * FROM food_donations ORDER BY donation_id DESC";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                model.addRow(new Object[]{
                    rs.getInt("donation_id"),
                    rs.getString("food_name"),
                    rs.getInt("quantity"),
                    rs.getString("pickup_location"),
                    rs.getTimestamp("available_until"),
                    rs.getString("donation_status")
                });
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    // UPDATE DONATION STATUS
    private void updateStatus() {

        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                this, "Please select a donation!"
            );
            return;
        }

        int donationId = (int) model.getValueAt(selectedRow, 0);
        String newStatus = (String) statusBox.getSelectedItem();

        String sql =
            "UPDATE food_donations SET donation_status=? WHERE donation_id=?";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, newStatus);
            ps.setInt(2, donationId);

            ps.executeUpdate();

            ps.close();
            con.close();

            JOptionPane.showMessageDialog(
                this, "Donation status updated!"
            );

            loadDonations();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    // DELETE DONATION
    private void deleteDonation() {

        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                this, "Please select a donation!"
            );
            return;
        }

        int donationId = (int) model.getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete this donation?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {

            String sql =
                "DELETE FROM food_donations WHERE donation_id=?";

            try {
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);

                ps.setInt(1, donationId);
                ps.executeUpdate();

                ps.close();
                con.close();

                JOptionPane.showMessageDialog(
                    this, "Donation deleted successfully!"
                );

                loadDonations();

            } catch (Exception e) {

                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }
}

