
package src;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Register extends JFrame {

    JTextField nameField, emailField, phoneField, addressField;
    JPasswordField passwordField;

    Color maroon = new Color(128, 25, 45);
    Color cream = new Color(255, 248, 238);
    Color orange = new Color(238, 145, 55);
    Color darkText = new Color(65, 45, 40);

    public Register() {

        setTitle("Food Delivery - Customer Registration");
        setSize(850, 650);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new GridLayout(1, 2));

        // LEFT BRANDING PANEL
        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(maroon);
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(new EmptyBorder(100, 30, 50, 30));

        JLabel brandTitle = new JLabel("FOOD DELIVERY");
        brandTitle.setFont(new Font("Arial", Font.BOLD, 29));
        brandTitle.setForeground(Color.WHITE);
        brandTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel tagline = new JLabel("Good Food, Great Mood!");
        tagline.setFont(new Font("Arial", Font.ITALIC, 17));
        tagline.setForeground(new Color(255, 210, 150));
        tagline.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel welcome = new JLabel("Join Our Food Family!");
        welcome.setFont(new Font("Arial", Font.BOLD, 21));
        welcome.setForeground(Color.WHITE);
        welcome.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel message = new JLabel(
            "<html><center>Register today and enjoy<br>" +
            "delicious food at your doorstep!</center></html>"
        );
        message.setFont(new Font("Arial", Font.PLAIN, 15));
        message.setForeground(Color.WHITE);
        message.setAlignmentX(Component.CENTER_ALIGNMENT);

        leftPanel.add(Box.createVerticalGlue());
        leftPanel.add(brandTitle);
        leftPanel.add(Box.createVerticalStrut(15));
        leftPanel.add(tagline);
        leftPanel.add(Box.createVerticalStrut(65));
        leftPanel.add(welcome);
        leftPanel.add(Box.createVerticalStrut(15));
        leftPanel.add(message);
        leftPanel.add(Box.createVerticalGlue());

        // RIGHT REGISTRATION PANEL
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(cream);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(cream);
        formPanel.setBorder(new EmptyBorder(25, 35, 25, 35));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 5, 7, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        JLabel title = new JLabel("CREATE ACCOUNT");
        title.setFont(new Font("Arial", Font.BOLD, 25));
        title.setForeground(maroon);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(title, gbc);

        gbc.gridwidth = 1;

        nameField = new JTextField();
        emailField = new JTextField();
        passwordField = new JPasswordField();
        phoneField = new JTextField();
        addressField = new JTextField();

        addField(formPanel, gbc, "Full Name", nameField, 1);
        addField(formPanel, gbc, "Email Address", emailField, 2);
        addField(formPanel, gbc, "Password", passwordField, 3);
        addField(formPanel, gbc, "Phone Number", phoneField, 4);
        addField(formPanel, gbc, "Address", addressField, 5);

        JButton registerButton = new JButton("CREATE ACCOUNT");
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        registerButton.setBackground(maroon);
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        registerButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        gbc.gridx = 0;
        gbc.gridy = 11;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 5, 10, 5);
        formPanel.add(registerButton, gbc);

        JButton backButton = new JButton("BACK TO WELCOME");
        backButton.setFont(new Font("Arial", Font.BOLD, 13));
        backButton.setBackground(orange);
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        gbc.gridy = 12;
        gbc.insets = new Insets(5, 5, 5, 5);
        formPanel.add(backButton, gbc);

        registerButton.addActionListener(e -> registerCustomer());

        backButton.addActionListener(e -> {
            dispose();
            new Welcome();
        });

        rightPanel.add(formPanel);

        mainPanel.add(leftPanel);
        mainPanel.add(rightPanel);

        add(mainPanel);
        setVisible(true);
    }

   
private void addField(JPanel panel, GridBagConstraints gbc,
                      String labelText, JTextField field, int row) {

    JLabel label = new JLabel(labelText);
    label.setFont(new Font("Arial", Font.BOLD, 13));
    label.setForeground(darkText);

    field.setFont(new Font("Arial", Font.PLAIN, 14));
    field.setPreferredSize(new Dimension(250, 34));
    field.setBackground(Color.WHITE);

    // Label position
    gbc.gridx = 0;
    gbc.gridy = (row * 2) - 1;
    gbc.gridwidth = 2;
    gbc.insets = new Insets(5, 5, 2, 5);
    panel.add(label, gbc);

    // Text field position
    gbc.gridx = 0;
    gbc.gridy = row * 2;
    gbc.insets = new Insets(2, 5, 5, 5);
    panel.add(field, gbc);
}

    private void registerCustomer() {

        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        String phone = phoneField.getText().trim();
        String address = addressField.getText().trim();

        if (name.isEmpty() || email.isEmpty() ||
            password.isEmpty() || phone.isEmpty() ||
            address.isEmpty()) {

            JOptionPane.showMessageDialog(this,
                "Please fill all fields!");
            return;
        }

        String sql = "INSERT INTO customers " +
            "(name, email, password, phone, address) " +
            "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setString(4, phone);
            ps.setString(5, address);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,
                "Registration Successful!");

            dispose();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Registration Failed: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new Register();
    }
}
