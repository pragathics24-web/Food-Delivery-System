
package src;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class AdminDashboard extends JFrame {

    Color maroon = new Color(105, 25, 38);
    Color cream = new Color(250, 244, 232);
    Color orange = new Color(230, 135, 55);
    Color darkText = new Color(65, 45, 40);

    public AdminDashboard() {

        setTitle("Food Delivery - Admin Dashboard");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(cream);

        // HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(maroon);
        header.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        JLabel title = new JLabel("FOOD DELIVERY");
        title.setFont(new Font("Arial", Font.BOLD, 27));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel("ADMIN DASHBOARD");
        subtitle.setFont(new Font("Arial", Font.BOLD, 14));
        subtitle.setForeground(new Color(255, 210, 160));

        JPanel headingPanel = new JPanel(new GridLayout(2, 1, 3, 3));
        headingPanel.setOpaque(false);
        headingPanel.add(title);
        headingPanel.add(subtitle);

        header.add(headingPanel, BorderLayout.WEST);
        mainPanel.add(header, BorderLayout.NORTH);

        // CONTENT
        JPanel content = new JPanel(new BorderLayout(15, 20));
        content.setBackground(cream);
        content.setBorder(BorderFactory.createEmptyBorder(30, 35, 30, 35));

        JLabel welcome = new JLabel("Welcome, Admin!");
        welcome.setFont(new Font("Arial", Font.BOLD, 25));
        welcome.setForeground(darkText);

        JLabel description = new JLabel("Manage your food delivery system");
        description.setFont(new Font("Arial", Font.PLAIN, 15));
        description.setForeground(Color.GRAY);

        JPanel welcomePanel = new JPanel(new GridLayout(2, 1, 5, 5));
        welcomePanel.setBackground(cream);
        welcomePanel.add(welcome);
        welcomePanel.add(description);

        content.add(welcomePanel, BorderLayout.NORTH);

        // BUTTONS
        JPanel buttonPanel = new JPanel(new GridLayout(3, 2, 20, 20));
        buttonPanel.setBackground(cream);

        JButton customersButton = createButton("VIEW CUSTOMERS");
        JButton foodButton = createButton("VIEW FOOD ITEMS");
        JButton ordersButton = createButton("VIEW ALL ORDERS");
        JButton paymentsButton = createButton("VIEW PAYMENTS");
        JButton donationButton = createButton("FOOD DONATION");

        customersButton.addActionListener(e -> showCustomers());
        foodButton.addActionListener(e -> showFoodItems());
        ordersButton.addActionListener(e -> showOrders());
        paymentsButton.addActionListener(e -> showPayments());

        // FOOD DONATION BUTTON
        donationButton.setBackground(orange);
        donationButton.addActionListener(e -> {
            new FoodDonationAdmin();
        });

        buttonPanel.add(customersButton);
        buttonPanel.add(foodButton);
        buttonPanel.add(ordersButton);
        buttonPanel.add(paymentsButton);
        buttonPanel.add(donationButton);

        content.add(buttonPanel, BorderLayout.CENTER);

        // LOGOUT
        JButton logoutButton = createButton("LOGOUT");
        logoutButton.setBackground(orange);
        logoutButton.setForeground(Color.WHITE);

        logoutButton.addActionListener(e -> {
            dispose();
            new AdminLogin();
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(cream);
        bottomPanel.add(logoutButton);

        content.add(bottomPanel, BorderLayout.SOUTH);

        mainPanel.add(content, BorderLayout.CENTER);

        add(mainPanel);
        setVisible(true);
    }

    private JButton createButton(String text) {

        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(maroon);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(20, 15, 20, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        return button;
    }

    // VIEW CUSTOMERS
    private void showCustomers() {

        String sql =
            "SELECT customer_id, name, email, phone, address FROM customers";

        showTable(sql, new String[]{
            "Customer ID", "Name", "Email", "Phone", "Address"
        }, "CUSTOMER DETAILS");
    }

    // VIEW FOOD ITEMS
    private void showFoodItems() {

        String sql =
            "SELECT food_id, food_name, category, price FROM food";

        showTable(sql, new String[]{
            "Food ID", "Food Name", "Category", "Price"
        }, "FOOD ITEMS");
    }

    // VIEW ALL ORDERS AND UPDATE STATUS
    private void showOrders() {

        String sql =
            "SELECT o.order_id, c.name, o.order_date, " +
            "o.total_amount, o.status " +
            "FROM orders o JOIN customers c " +
            "ON o.customer_id = c.customer_id " +
            "ORDER BY o.order_id DESC";

        JFrame frame = new JFrame("ALL CUSTOMER ORDERS");
        frame.setSize(900, 500);
        frame.setLocationRelativeTo(this);
        frame.setLayout(new BorderLayout(10, 10));
        frame.getContentPane().setBackground(cream);

        String[] columns = {
            "Order ID", "Customer", "Date", "Total", "Status"
        };

        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        table.setRowHeight(32);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.getTableHeader().setBackground(maroon);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("order_id"),
                    rs.getString("name"),
                    rs.getDate("order_date"),
                    rs.getBigDecimal("total_amount"),
                    rs.getString("status")
                });
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, e.getMessage());
        }

        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        // STATUS UPDATE PANEL
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(cream);

        JLabel label = new JLabel("Update Order Status:");
        label.setFont(new Font("Arial", Font.BOLD, 14));

        String[] statuses = {
            "Pending",
            "Preparing",
            "Out for Delivery",
            "Delivered"
        };

        JComboBox<String> statusBox = new JComboBox<>(statuses);

        JButton updateButton = createButton("UPDATE ORDER STATUS");

        updateButton.addActionListener(e -> {

            int selectedRow = table.getSelectedRow();

            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(
                    frame, "Please select an order first!"
                );
                return;
            }

            int orderId = (int) model.getValueAt(selectedRow, 0);
            String newStatus = (String) statusBox.getSelectedItem();

            int confirm = JOptionPane.showConfirmDialog(
                frame,
                "Update Order ID " + orderId + " to " + newStatus + "?",
                "Confirm Status Update",
                JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {

                String updateSql =
                    "UPDATE orders SET status=? WHERE order_id=?";

                try {
                    Connection con = DBConnection.getConnection();
                    PreparedStatement ps = con.prepareStatement(updateSql);

                    ps.setString(1, newStatus);
                    ps.setInt(2, orderId);

                    ps.executeUpdate();

                    ps.close();
                    con.close();

                    JOptionPane.showMessageDialog(
                        frame, "Order status updated successfully!"
                    );

                    frame.dispose();
                    showOrders();

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(
                        frame, ex.getMessage()
                    );
                }
            }
        });

        bottomPanel.add(label);
        bottomPanel.add(statusBox);
        bottomPanel.add(updateButton);

        frame.add(bottomPanel, BorderLayout.SOUTH);
        frame.setVisible(true);
    }

    // VIEW PAYMENTS
    private void showPayments() {

        String sql =
            "SELECT p.payment_id, p.order_id, c.name, " +
            "p.payment_method, p.payment_status, p.payment_date " +
            "FROM payments p " +
            "JOIN orders o ON p.order_id = o.order_id " +
            "JOIN customers c ON o.customer_id = c.customer_id " +
            "ORDER BY p.payment_id DESC";

        showTable(sql, new String[]{
            "Payment ID", "Order ID", "Customer Name",
            "Payment Method", "Payment Status", "Payment Date"
        }, "PAYMENT DETAILS");
    }

    // COMMON TABLE METHOD
    private void showTable(
        String sql, String[] columns, String heading
    ) {

        JFrame frame = new JFrame(heading);
        frame.setSize(900, 450);
        frame.setLocationRelativeTo(this);
        frame.getContentPane().setBackground(cream);

        DefaultTableModel model =
            new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

        JTable table = new JTable(model);
        table.setRowHeight(32);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.setForeground(darkText);
        table.setBackground(Color.WHITE);
        table.setGridColor(new Color(235, 220, 205));
        table.setSelectionBackground(new Color(245, 220, 195));
        table.setSelectionForeground(darkText);

        table.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 13)
        );
        table.getTableHeader().setBackground(maroon);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setPreferredSize(new Dimension(0, 38));

        DefaultTableCellRenderer centerRenderer =
            new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i)
                .setCellRenderer(centerRenderer);
        }

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            int columnCount = rs.getMetaData().getColumnCount();

            while (rs.next()) {
                Object[] row = new Object[columnCount];

                for (int i = 0; i < columnCount; i++) {
                    row[i] = rs.getObject(i + 1);
                }

                model.addRow(row);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, e.getMessage());
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setBackground(Color.WHITE);

        frame.add(scrollPane);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminDashboard());
    }
}
