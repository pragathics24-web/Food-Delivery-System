
package src;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FoodDonationCustomer extends JFrame {

    Color maroon = new Color(105, 25, 38);
    Color cream = new Color(250, 244, 232);
    Color orange = new Color(230, 135, 55);

    private JTable table;
    private DefaultTableModel model;

    public FoodDonationCustomer() {

        setTitle("Available Food Donations");
        setSize(850, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBackground(cream);
        mainPanel.setBorder(
            BorderFactory.createEmptyBorder(25, 25, 25, 25)
        );

        JLabel heading = new JLabel("AVAILABLE FOOD DONATIONS");
        heading.setFont(new Font("Arial", Font.BOLD, 23));
        heading.setForeground(maroon);

        mainPanel.add(heading, BorderLayout.NORTH);

        String[] columns = {
            "Donation ID",
            "Food Name",
            "Quantity",
            "Pickup Location",
            "Available Until",
            "Status"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.getTableHeader().setBackground(maroon);
        table.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(table);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(cream);

        JButton requestButton = new JButton("REQUEST FOOD");
        requestButton.setBackground(orange);
        requestButton.setForeground(Color.WHITE);
        requestButton.setFont(new Font("Arial", Font.BOLD, 14));
        requestButton.setFocusPainted(false);

        JButton refreshButton = new JButton("REFRESH");
        refreshButton.setBackground(maroon);
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Arial", Font.BOLD, 14));
        refreshButton.setFocusPainted(false);

        requestButton.addActionListener(e -> requestFood());
        refreshButton.addActionListener(e -> loadDonations());

        bottomPanel.add(requestButton);
        bottomPanel.add(refreshButton);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);

        loadDonations();

        setVisible(true);
    }

    // LOAD AVAILABLE DONATIONS
    private void loadDonations() {

        model.setRowCount(0);

        String sql =
            "SELECT * FROM food_donations " +
            "WHERE donation_status='Available' " +
            "AND available_until > NOW() " +
            "ORDER BY donation_id DESC";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                model.addRow(new Object[]{
                    rs.getInt("donation_id"),
                    rs.getString("food_name"),
                    rs.getInt("quantity"),
                    rs.getString("pickup_location"),
                    rs.getTimestamp("available_until"),
                    rs.getString("donation_status")
                });
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    // REQUEST FOOD
    private void requestFood() {

        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                this, "Please select a food donation!"
            );
            return;
        }

        int donationId =
            (int) model.getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Do you want to request this food?",
            "Confirm Request",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {

            String sql =
                "UPDATE food_donations " +
                "SET donation_status='Requested' " +
                "WHERE donation_id=? AND donation_status='Available'";

            try {
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);

                ps.setInt(1, donationId);

                int result = ps.executeUpdate();

                ps.close();
                con.close();

                if (result > 0) {
                    JOptionPane.showMessageDialog(
                        this,
                        "Food requested successfully!"
                    );
                } else {
                    JOptionPane.showMessageDialog(
                        this,
                        "Sorry! This donation is no longer available."
                    );
                }

                loadDonations();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(
            () -> new FoodDonationCustomer()
        );
    }
}

