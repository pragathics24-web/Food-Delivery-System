
package src;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Cart extends JFrame {

    private JTable cartTable;
    private DefaultTableModel model;
    private JLabel totalLabel;

    private final Color MAROON = new Color(128, 25, 45);
    private final Color CREAM = new Color(255, 248, 238);
    private final Color ORANGE = new Color(238, 145, 55);

    public Cart() {

        setTitle("Shopping Cart");
        setSize(750, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBackground(CREAM);
        mainPanel.setBorder(
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        );

        JLabel heading = new JLabel(
            "MY SHOPPING CART", SwingConstants.CENTER
        );
        heading.setFont(new Font("Arial", Font.BOLD, 25));
        heading.setForeground(MAROON);

        mainPanel.add(heading, BorderLayout.NORTH);

        // TABLE
        String[] columns = {
            "Food ID", "Food Name", "Price",
            "Quantity", "Total"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        cartTable = new JTable(model);
        cartTable.setRowHeight(30);
        cartTable.setFont(new Font("Arial", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(cartTable);

        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // BOTTOM PANEL
        JPanel bottomPanel = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 15, 10)
        );

        bottomPanel.setBackground(CREAM);

        totalLabel = new JLabel();
        totalLabel.setFont(
            new Font("Arial", Font.BOLD, 19)
        );
        totalLabel.setForeground(MAROON);

        JButton removeButton = new JButton("REMOVE ITEM");
        JButton clearButton = new JButton("CLEAR CART");
        JButton closeButton = new JButton("CLOSE");

        styleButton(removeButton, MAROON);
        styleButton(clearButton, ORANGE);
        styleButton(closeButton, MAROON);

        removeButton.addActionListener(e -> removeItem());

        clearButton.addActionListener(e -> clearCart());

        closeButton.addActionListener(e -> dispose());

        bottomPanel.add(totalLabel);
        bottomPanel.add(removeButton);
        bottomPanel.add(clearButton);
        bottomPanel.add(closeButton);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);

        loadCartItems();

        setVisible(true);
    }

    // LOAD CART ITEMS
    private void loadCartItems() {

        model.setRowCount(0);

        for (CartItem item : CartManager.getCartItems()) {

            model.addRow(new Object[] {
                item.getFoodId(),
                item.getFoodName(),
                item.getPrice(),
                item.getQuantity(),
                item.getTotal()
            });
        }

        totalLabel.setText(
            String.format(
                "Grand Total: Rs. %.2f",
                CartManager.getGrandTotal()
            )
        );
    }

    // REMOVE SELECTED ITEM
    private void removeItem() {

        int selectedRow = cartTable.getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                this, "Please select an item!"
            );

            return;
        }

        int foodId = (int) model.getValueAt(
            selectedRow, 0
        );

        CartManager.removeItem(foodId);

        loadCartItems();

        JOptionPane.showMessageDialog(
            this, "Item Removed Successfully!"
        );
    }

    // CLEAR CART
    private void clearCart() {

        if (CartManager.getCartItems().isEmpty()) {
            JOptionPane.showMessageDialog(
                this, "Cart is already empty!"
            );
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to clear the cart?",
            "Clear Cart",
            JOptionPane.YES_NO_OPTION
        );

        if (choice == JOptionPane.YES_OPTION) {

            CartManager.clearCart();

            loadCartItems();
        }
    }

    // BUTTON DESIGN
    private void styleButton(
        JButton button, Color color
    ) {

        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(
            new Font("Arial", Font.BOLD, 13)
        );
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(
            new Dimension(135, 40)
        );
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> new Cart());
    }
}
