package src;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class OrderHistory extends JFrame {

    private int customerId;
    private DefaultTableModel model;   // field aaki irukken
    private JTable table;              // field aaki irukken

    private final Color MAROON = new Color(128, 25, 45);
    private final Color CREAM = new Color(255, 248, 238);
    private final Color ORANGE = new Color(238, 145, 55);
    private final Color DARK = new Color(65, 45, 40);

    public OrderHistory(int customerId) {

        this.customerId = customerId;

        setTitle("Food Delivery - My Order History");
        setSize(1150, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(CREAM);

        // HEADER
        JPanel headerPanel = new JPanel(new GridLayout(2, 1));
        headerPanel.setBackground(MAROON);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(18, 10, 18, 10));

        JLabel title = new JLabel("MY ORDER HISTORY", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel(
            "Your delicious orders, all in one place!", SwingConstants.CENTER);
        subtitle.setFont(new Font("Arial", Font.ITALIC, 15));
        subtitle.setForeground(new Color(255, 220, 160));

        headerPanel.add(title);
        headerPanel.add(subtitle);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // TABLE COLUMNS
        String[] columns = {
            "Order ID", "Food Name", "Quantity", "Price", "Total",
            "Order Date", "Order Status", "Payment Method", "Payment Status"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setRowHeight(38);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.setForeground(DARK);
        table.setBackground(Color.WHITE);
        table.setSelectionBackground(new Color(255, 220, 180));
        table.setSelectionForeground(DARK);
        table.setGridColor(new Color(230, 205, 185));
        table.setShowGrid(true);
        table.setFillsViewportHeight(true);

        // TABLE HEADER DESIGN
        JTableHeader tableHeader = table.getTableHeader();
        tableHeader.setPreferredSize(new Dimension(0, 45));
        tableHeader.setBackground(MAROON);
        tableHeader.setForeground(Color.WHITE);
        tableHeader.setFont(new Font("Arial", Font.BOLD, 13));
        tableHeader.setReorderingAllowed(false);

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(MAROON);
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setFont(new Font("Arial", Font.BOLD, 13));
        headerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }

        // CENTER ALIGN TABLE CONTENT
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        scrollPane.getViewport().setBackground(CREAM);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // LOAD ORDER HISTORY
        loadOrderHistory();

        // FOOTER
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        footerPanel.setBackground(MAROON);
        footerPanel.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));

        // CANCEL ORDER BUTTON
        JButton cancelButton = new JButton("CANCEL ORDER");
        cancelButton.setFont(new Font("Arial", Font.BOLD, 14));
        cancelButton.setBackground(new Color(200, 40, 40));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);
        cancelButton.setBorder(BorderFactory.createEmptyBorder(12, 45, 12, 45));
        cancelButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        cancelButton.addActionListener(e -> {
            int row = table.getSelectedRow();

            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Please select an order first!");
                return;
            }

            int orderId = Integer.parseInt(table.getValueAt(row, 0).toString());
            String status = table.getValueAt(row, 6).toString();

            if (status.equalsIgnoreCase("CANCELLED")
                    || status.equalsIgnoreCase("DELIVERED")) {
                JOptionPane.showMessageDialog(this,
                    "Order already " + status + ". Cancel panna mudiyadhu!");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                "Order #" + orderId + " cancel pannanuma?",
                "Confirm Cancel", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                cancelOrder(orderId);
            }
        });

        // CLOSE BUTTON
        JButton closeButton = new JButton("CLOSE");
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.setBackground(ORANGE);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setBorder(BorderFactory.createEmptyBorder(12, 45, 12, 45));
        closeButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        closeButton.addActionListener(e -> dispose());

        footerPanel.add(cancelButton);
        footerPanel.add(closeButton);
        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }

    // CANCEL ORDER
    private void cancelOrder(int orderId) {

        try (Connection con = DBConnection.getConnection()) {

            con.setAutoCommit(false);

            try {
                // 1. Check status (and make sure order is this customer's)
                String checkSql =
                    "SELECT status FROM orders WHERE order_id = ? AND customer_id = ?";

                try (PreparedStatement ps = con.prepareStatement(checkSql)) {
                    ps.setInt(1, orderId);
                    ps.setInt(2, customerId);

                    ResultSet rs = ps.executeQuery();

                    if (!rs.next()) {
                        JOptionPane.showMessageDialog(this, "Order not found!");
                        return;
                    }

                    String status = rs.getString("status");
                    if ("CANCELLED".equalsIgnoreCase(status)
                            || "DELIVERED".equalsIgnoreCase(status)) {
                        JOptionPane.showMessageDialog(this,
                            "Order already " + status + ". Cancel panna mudiyadhu!");
                        return;
                    }
                }

                // 2. Update order status
                String updateOrder =
                    "UPDATE orders SET status = 'CANCELLED' WHERE order_id = ?";

                try (PreparedStatement ps = con.prepareStatement(updateOrder)) {
                    ps.setInt(1, orderId);
                    ps.executeUpdate();
                }

                // 3. Update payment status (optional - unga payment_status values ku match pannunga)
                String updatePayment =
                    "UPDATE payments SET payment_status = 'CANCELLED' WHERE order_id = ?";

                try (PreparedStatement ps = con.prepareStatement(updatePayment)) {
                    ps.setInt(1, orderId);
                    ps.executeUpdate();
                }

                con.commit();

                JOptionPane.showMessageDialog(this, "Order cancelled successfully!");
                loadOrderHistory();   // table refresh

            } catch (SQLException ex) {
                con.rollback();
                throw ex;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    // LOAD ORDER HISTORY
    private void loadOrderHistory() {

        model.setRowCount(0);   // old rows clear (refresh ku important)

        String sql =
            "SELECT o.order_id, f.food_name, oi.quantity, " +
            "oi.price, o.total_amount, o.order_date, o.status, " +
            "p.payment_method, p.payment_status " +
            "FROM orders o " +
            "JOIN order_items oi ON o.order_id = oi.order_id " +
            "JOIN food f ON oi.food_id = f.food_id " +
            "LEFT JOIN payments p ON o.order_id = p.order_id " +
            "WHERE o.customer_id = ? " +
            "ORDER BY o.order_id DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();

            boolean found = false;

            while (rs.next()) {
                found = true;

                Object[] row = {
                    rs.getInt("order_id"),
                    rs.getString("food_name"),
                    rs.getInt("quantity"),
                    "Rs. " + rs.getDouble("price"),
                    "Rs. " + rs.getDouble("total_amount"),
                    rs.getDate("order_date"),
                    rs.getString("status"),
                    rs.getString("payment_method") == null
                        ? "Not Available" : rs.getString("payment_method"),
                    rs.getString("payment_status") == null
                        ? "Not Available" : rs.getString("payment_status")
                };

                model.addRow(row);
            }

            if (!found) {
                JOptionPane.showMessageDialog(this, "No orders found!");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
}