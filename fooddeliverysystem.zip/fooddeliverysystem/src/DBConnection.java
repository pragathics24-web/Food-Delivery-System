
package src;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    public static Connection getConnection() {

        String url = "jdbc:mysql://localhost:3306/food_delivery";
        String user = "root";
        String password = "";

        try {
            Connection con = DriverManager.getConnection(
                url, user, password
            );

            return con;

        } catch (Exception e) {
            System.out.println("Database Connection Failed!");
            e.printStackTrace();
            return null;
        }
    }
}
