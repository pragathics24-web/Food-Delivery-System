
package src;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Welcome extends JFrame {

    Color RED = new Color(190, 35, 35);
    Color ORANGE = new Color(245, 135, 35);
    Color CREAM = new Color(255, 247, 235);
    Color DARK = new Color(65, 35, 30);

    public Welcome() {

        setTitle("Food Delivery System");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel main = new JPanel(new GridLayout(1, 2));

        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setBackground(RED);
        left.setBorder(new EmptyBorder(60, 30, 50, 30));

        JLabel logo = new JLabel();
        ImageIcon icon = new ImageIcon("logo.png");

        if (icon.getIconWidth() > 0) {
            Image img = icon.getImage().getScaledInstance(
                260, 260, Image.SCALE_SMOOTH
            );
            logo.setIcon(new ImageIcon(img));
        } else {
            logo.setText("FOOD DELIVERY");
            logo.setForeground(Color.WHITE);
            logo.setFont(new Font("Arial", Font.BOLD, 27));
        }

        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel tagline = new JLabel("GOOD FOOD, GREAT MOOD!");
        tagline.setForeground(Color.WHITE);
        tagline.setFont(new Font("Arial", Font.BOLD, 20));
        tagline.setAlignmentX(Component.CENTER_ALIGNMENT);

        left.add(Box.createVerticalGlue());
        left.add(logo);
        left.add(Box.createVerticalStrut(25));
        left.add(tagline);
        left.add(Box.createVerticalGlue());

        JPanel right = new JPanel();
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setBackground(CREAM);
        right.setBorder(new EmptyBorder(120, 55, 100, 55));

        JLabel heading = new JLabel("Welcome!");
        heading.setFont(new Font("Arial", Font.BOLD, 32));
        heading.setForeground(DARK);
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel("Choose your login type");
        subtitle.setFont(new Font("Arial", Font.PLAIN, 16));
        subtitle.setForeground(Color.GRAY);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton userButton = new JButton("USER LOGIN");
        JButton adminButton = new JButton("ADMIN LOGIN");
        JButton registerButton = new JButton("CREATE NEW ACCOUNT");

        styleButton(userButton, RED);
        styleButton(adminButton, ORANGE);
        styleButton(registerButton, DARK);

        userButton.addActionListener(e -> {
            dispose();
            new Login();
        });

        adminButton.addActionListener(e -> {
            dispose();
            new AdminLogin();
        });

        registerButton.addActionListener(e -> {
            dispose();
            new Register();
        });

        right.add(heading);
        right.add(Box.createVerticalStrut(10));
        right.add(subtitle);
        right.add(Box.createVerticalStrut(45));
        right.add(userButton);
        right.add(Box.createVerticalStrut(20));
        right.add(adminButton);
        right.add(Box.createVerticalStrut(20));
        right.add(registerButton);

        main.add(left);
        main.add(right);

        add(main);
        setVisible(true);
    }

    private void styleButton(JButton button, Color color) {
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setMaximumSize(new Dimension(350, 45));
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Welcome());
    }
}

